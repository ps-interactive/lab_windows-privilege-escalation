<#
.SYNOPSIS
    Enumerates COM objects and identifies those that may be vulnerable
    to Potato-style privilege escalation (weak DCOM permissions +
    SYSTEM-level COM servers).

.DESCRIPTION
    This tool scans HKLM\SOFTWARE\Classes for:

        • CLSIDs with LocalServer32 binaries
        • AppIDs that run as SYSTEM
        • Weak LaunchPermission / AccessPermission descriptors
        • Maps AppID → CLSID

    Use this in labs to identify misconfigured COM objects.
#>

Write-Host ""
Write-Host "=== Find-CLSIDs.ps1 - COM Vulnerability Enumerator ===" -ForegroundColor Cyan
Write-Host ""

# Collect results
$vulnList = @()

# -------------------------------
# Step 1 – Enumerate AppIDs
# -------------------------------
$appIdInfo = @{}

Get-ChildItem "HKLM:\SOFTWARE\Classes\AppID" | ForEach-Object {
    $appid = $_.PSChildName
    $props = Get-ItemProperty $_.PsPath -ErrorAction SilentlyContinue

    $runAs = $props.RunAs
    $launchPerm = $props.LaunchPermission
    $accessPerm = $props.AccessPermission

    $weakLaunch = $false
    $weakAccess = $false

    # Decode ASCII security descriptors (lab-safe)
    if ($launchPerm) {
        $ascii = [System.Text.Encoding]::ASCII.GetString($launchPerm)
        if ($ascii -match "WD") { $weakLaunch = $true }
    }
    if ($accessPerm) {
        $ascii2 = [System.Text.Encoding]::ASCII.GetString($accessPerm)
        if ($ascii2 -match "WD") { $weakAccess = $true }
    }

    $appIdInfo[$appid] = [PSCustomObject]@{
        AppID = $appid
        RunAs = $runAs
        WeakLaunch = $weakLaunch
        WeakAccess = $weakAccess
    }
}

# -------------------------------
# Step 2 – Map CLSIDs to AppIDs
# -------------------------------
Get-ChildItem "HKLM:\SOFTWARE\Classes\CLSID" | ForEach-Object {

    $clsid = $_.PSChildName

    # Must have a LocalServer32 (COM service)
    $ls32Path = "$($_.PsPath)\LocalServer32"
    if (-not (Test-Path $ls32Path)) { return }

    $localServer = (Get-ItemProperty $ls32Path -ErrorAction SilentlyContinue)."(Default)"

    # Map to AppID if present
    $appid = (Get-ItemProperty $_.PsPath -ErrorAction SilentlyContinue).AppID

    if ($appid -and $appIdInfo.ContainsKey($appid)) {
        $info = $appIdInfo[$appid]

        # Check if SYSTEM RunAs and weak permissions present
        if ($info.RunAs -eq "NT AUTHORITY\SYSTEM" -and ($info.WeakLaunch -or $info.WeakAccess)) {

            $vulnList += [PSCustomObject]@{
                CLSID          = $clsid
                AppID          = $appid
                LocalServer32  = $localServer
                RunAs          = $info.RunAs
                WeakLaunchPerm = $info.WeakLaunch
                WeakAccessPerm = $info.WeakAccess
            }
        }
    }
}

# -------------------------------
# Step 3 – Output results
# -------------------------------
if ($vulnList.Count -eq 0) {
    Write-Host "No vulnerable CLSIDs found." -ForegroundColor Yellow
} else {
    Write-Host "Possible vulnerable CLSIDs detected:" -ForegroundColor Green
    Write-Host ""

    $vulnList | Format-Table CLSID, AppID, LocalServer32, RunAs
    Write-Host ""
    Write-Host "Use SweetPotato.exe with:  -c {CLSID}  -p <payload.exe>" -ForegroundColor Cyan
}

Write-Host ""
