param(
    [Parameter(Mandatory=$true)]
    [int]$ProcessID,

    [Parameter(Mandatory=$true)]
    [string]$DllPath
)

$DllPath = (Resolve-Path $DllPath).Path

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class Win32 {
    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("kernel32.dll", SetLastError=true)]
    public static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize,
        IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, out IntPtr lpThreadId);
}
"@

$PROCESS_ALL_ACCESS = 0x001F0FFF
$MEM_COMMIT = 0x1000
$PAGE_READWRITE = 0x04

Write-Host "[+] Opening process $ProcessID ..."
$hProcess = [Win32]::OpenProcess($PROCESS_ALL_ACCESS, $false, $ProcessID)
if ($hProcess -eq [IntPtr]::Zero) { throw "[-] Failed to open process." }

# Convert DLL path → byte array (ASCII)
$dllBytes = [System.Text.Encoding]::ASCII.GetBytes($DllPath)
$size = $dllBytes.Length + 1

Write-Host "[+] Allocating memory..."
$addr = [Win32]::VirtualAllocEx($hProcess, [IntPtr]::Zero, $size, $MEM_COMMIT, $PAGE_READWRITE)
if ($addr -eq [IntPtr]::Zero) { throw "[-] VirtualAllocEx failed." }

Write-Host "[+] Writing DLL path..."
# >>> FIXED WRITEPROCESSMEMORY BLOCK <<<
$bytesWritten = [UIntPtr]::Zero
$success = [Win32]::WriteProcessMemory(
    $hProcess, $addr, $dllBytes,
    [uint32]$dllBytes.Length,
    [ref]$bytesWritten
)
if (-not $success) {
    throw "[-] WriteProcessMemory failed. Win32Error: $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
}

Write-Host "[+] Getting LoadLibraryA address..."
$kernel32 = [Win32]::GetModuleHandle("kernel32.dll")
$loadLib = [Win32]::GetProcAddress($kernel32, "LoadLibraryA")

Write-Host "[+] Creating remote thread..."
$threadId = [IntPtr]::Zero
$thread = [Win32]::CreateRemoteThread($hProcess, [IntPtr]::Zero, 0, $loadLib, $addr, 0, [ref]$threadId)

if ($thread -eq [IntPtr]::Zero) {
    throw "[-] CreateRemoteThread failed."
}

Write-Host "[+] DLL successfully injected!"
Write-Host "[+] Remote thread ID: $threadId"